hii 
hello<?php /**PATH C:\xampp\htdocs\gbhEcommBackend\resources\views/mail/name.blade.php ENDPATH**/ ?>